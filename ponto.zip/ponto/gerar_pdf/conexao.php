<?php
	$servidor = "localhost";
	$usuario = "pontopmc";
	$senha = "PontoCapivari2020";
	$dbname = "ponto";
	
	//Criar a conexão
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>