<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.css.map">
    <link rel="stylesheet" href="css/fingertechweb.css">
    <title>ESPELHO PONTO - PMC</title>
    </head>
    <body>			
    <center><img src="img/pref.jpg">

<main role="main" class="container">
			<div style="text-align: center; font-family: Arial;">
				
				<h1>Espelho Ponto - PMC</h1>
				<h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>
			</div>
            <div class="col-4">
        <form  method="POST" action="oldindex.php" class="form-group row justify-content-center" style="padding-top: 20px;">
                   
             <label for="matricula" ><b>Matricula:</b></label><br>
                        
              
                     <input  class="form-control" type="text" placeholder="Matricula"  required name="nome"> 
                                    
			
            
			
            <label for="data" ><b>Data:</b></label>
				
				  <input type="date" class="form-control"  placeholder="Data" name="data" required>
				

			<label for="data1" ><b>Data:</b></label>
			
				  <input type="date" class="form-control"  placeholder="Data" name="data1" required>
				</div>
			
				
		
                        <div  style="padding-left: 3px;"class="col-1">
                        <input type="submit"  style="  background-color:#007bff; font-family: Arial; color: white; border-color: #007bff ; border-radius: 5px; border: none;  font-size: 20px;"   name="buscar" value="Procurar">
                        </div>
                </form><br><br>

               <footer >
			<div style="text-align: center; font-family: Arial; padding-top: 150px;">
				<span class="text-muted">
					<b>DEPTO T.I. - 2020</b> <br />    

		</body>
        </html>	