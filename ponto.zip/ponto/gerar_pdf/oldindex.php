<?php	

	include_once("conexao.php");

	$a = $_POST['nome'];
	$data = $_POST['data'];
	$data1 = $_POST['data1'];

  
	$html = '<table border=1';	
	$html .= '<thead>';
	$html .= '<tr>';
	$html .= '<th>Matricula</th>';
	$html .= '<th>Nome</th>';
	$html .= '<th>Data</th>';
	$html .= '<th>Hora</th>';
	
	$html .= '</tr>';
	$html .= '</thead>';
	$html .= '<tbody>';
	
	$result_transacoes = "SELECT DISTINCT marcacao.matricula, client.name, marcacao.date, marcacao.hora from marcacao, client where client.matricula = marcacao.matricula and marcacao.matricula = '$a' 
	AND marcacao.date BETWEEN '$data' AND '$data1'";
	$resultado_trasacoes = mysqli_query($conn, $result_transacoes);
	while($row_transacoes = mysqli_fetch_assoc($resultado_trasacoes)){
		$html .= '<tr><td>'.$row_transacoes['matricula'] . "</td>";
		$html .= '<td>'.$row_transacoes['name'] . "</td>";
		$html .= '<td>'.$row_transacoes['date'] . "</td>";
		$html .= '<td>'.$row_transacoes['hora'] . "</td></tr>";		
	}
	
	$html .= '</tbody>';
	$html .= '</table>';

	
	//referenciar o DomPDF com namespace
	use Dompdf\Dompdf;

	// include autoloader
	require_once("dompdf/autoload.inc.php");

	//Criando a Instancia
	$dompdf = new DOMPDF();
	
	// Carrega seu HTML
	$dompdf->load_html('
			<h1 style="text-align: center; font-family: Arial;">Espelho do Ponto</h1>
			'. $html .'
		');

	//Renderizar o html
	$dompdf->render();

	//Exibibir a página
	$dompdf->stream(
		"ponto_" .$a .".pdf", 
		array(
			"Attachment" => false //Para realizar o download somente alterar para true
		)
	);
?>
