<?php
define('HOST', 'localhost');
define('USUARIO', 'pontopmc');
define('SENHA', 'PontoCapivari2020');
define('DB', 'ponto');

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');