<!DOCTYPE html>

      

  <html>

      <head>

        <title>SERVIÇO PONTO - PMC</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>

          .btn-group .button {

            background-color: #007bff;

            border: 1px solid #007bff;

            color: white;

            padding: 15px 32px;

            text-align: center;

            text-decoration: none;

            display: inline-block;

            font-size: 16px;

            cursor: pointer;

            float: center;

          }



          .btn-group .button:not(:last-child) {

            border-right: none; /* Prevent double borders */

          }



          .btn-group .button:hover {

            background-color: DodgerBlue;

          }

        </style>

      </head>

      <body>



          <center><img src="marcacao_ponto/relogio/img/pref.jpg">



              <main role="main" class="container">

                    <div style="text-align: center; font-family: Arial;">

                      

                      <h1>Serviço Ponto - PMC</h1>

                      <h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>

                    </div>

                          

                    <div class="btn-group">    

                

                     

                      <a target="_blank" href='marcacao_ponto/ponto.php'> <button class="button"> <b>PONTO </button> </a>

                      <a target="_blank" href='marcacao_ponto/p_matricula.php'> <button class="button"> <b>PESQUISA </button> </a>

                      

                     

                      <a target="_blank" href='gerar_pdf/index.php'> <button class="button"> <b>ESPELHO </button> </a>

                   </div>

                        

                   <footer >

                      <div style="text-align: center; font-family: Arial; padding-top: 150px;">

                          <span class="text-muted">

                            <b>DEPTO T.I. - 2020</b> <br /> 

                          </span>

                      </div>

                  </footer>

        </body>

</html>