<?php
require_once("Controller2.php");

$obj = new Controller();
$table = $obj->selectDB();
?>
<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<meta charset="utf-8" />
		<title>PONTO - PMC</title>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/fingertechweb.css" />
	</head>
	
	<body>
		<main role="main" class="container">
			<div style="text-align: center;">
				<img src="img/" width="60%" />
				<h1>Serviço de Ponto</h1>
				<h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>
			</div>
			
			<br />
			<div class="form-group row justify-content-center">
			
				<div class="col-6">
				  <input type="text" class="form-control" id="inputName" required placeholder="Digite seu nome..."><br>
				 
				  


				</div><br>
				
				<div class="col-1">
					<button class="btn btn-primary" id="btn-capture">Cadastrar</button>

					
				</div>
			</div>
			


			
			
			
			<div class="row" style="padding-left: 150px; padding-right: 150px; margin-bottom: 20px;">
				<table hidden class="table table-condensed">
					<thead class="thead-light">
						<tr>
							<th scope="col" hidden  class="col-1">ID</th>
							<th scope="col" class="col-2">Nome</th>
							<th scope="col"hidden class="col-8">Template</th>
							<th scope="col" class="col-1">Ação</th>
						</tr>
					</thead>
					<tbody>
						<?php echo $table; ?>
					</tbody>
				</table>
			</div>
			
		</main>
		
		<footer class="footer py-3">
			<div style="text-align: center;">
				<span class="text-muted">
				<b>DEPTO T.I. 2020</b> <br /> 
					<a href="https://prefeituracapivari.sp.gov.br/" target="_blank">www.prefeituracapivari.sp.gov.br</a>
				</span>
			</div>
		</footer>
	</body>
	
	<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/fingertechweb.js"></script>
</html>

