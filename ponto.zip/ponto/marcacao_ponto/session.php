<?php

session_start();

$_SESSION["newsession"] = $_POST['id'];

$v = $_POST['id'];

echo $v;



?>

