<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>PESQUISA NOME - PMC</title>
    </head>
    <body>	

  <center><img src="relogio/img/pref.jpg">

<main role="main" class="container">
      <div style="text-align: center; font-family: Arial;">
        
        
        <h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>
      </div>		
        <br><form method="post"  action="p_matricula.php" style="text-align: center;">
        <label  style="font-family: Arial; "for="pesquisa" ><b>Pesquisa:</b></label>
            
                <input type="text" style=" padding: 5.5px 20px;  border-radius: 4px;"  placeholder=" Digite seu nome..." name="nome">
            
            
                <input type="submit"  style=" background-color:#007bff; font-family: Arial; color: white; border-color: #007bff ; border-radius: 5px; border: none;  font-size: 20px;"   name="buscar" value="Procurar">
            
        </form><br>
                <div><br>
                    <?php

                    $servername = "localhost";
                    $database = "ponto";
                    $username = "pontopmc";
                    $password = "PontoCapivari2020";

                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $database);
                    // Check connection
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                    }

                    //conexão

                    //$_POST["nome"] = "";

                    $post = "%".$_POST["nome"]."%";

                    $fe = "SELECT matricula, name from client WHERE name like '$post' ORDER BY 02";


                    $todos = "SELECT matricula, name FROM client ORDER BY 02";



                    try {
                        $dbh = new PDO("mysql:host=$servername;dbname=$database", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
                        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        if( !empty($_POST) ) {
                            $sth = $dbh->prepare($fe);
                            $sth->bindParam(1, $post);


                        } else {
                            $sth = $dbh->prepare($todos);
                        }
                        $sth->execute();
                        $result = $sth->fetchAll(PDO::FETCH_ASSOC);
                        echo "<center><table class='' border=1 ><tr>";?>

                        <tr>
                        <th style="font-family: Arial;">Matricula</th>
                        <th style="font-family: Arial;">Nome</th>
                        
                        </tr>

                        <?php echo "</tr>";
                        foreach($result as $row) {
                            echo "<tr>";
                            foreach($row as $matricula => $value){
                                echo "<td>$value</td>";
                            }
                            
                        }
                        echo "</table>";
                        $dbh = null;
                    } catch (PDOException $e) {
                        print "Error!: " . $e->getMessage() . "<br/>";
                        die();
                    }

                    ?></center>
                </div>	


		</body>
        </html>	