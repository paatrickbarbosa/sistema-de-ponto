



"INSERT INTO client(name, template, date, hora) VALUES ('". $name ."','". $template ."', current_date(), current_time())";

<?php

session_start();

echo $a;

?>