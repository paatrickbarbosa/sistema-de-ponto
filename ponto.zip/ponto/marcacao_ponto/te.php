<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 40%;
  text-align: center;
  background-color: lightgrey;
  font-family: Arial;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 2px 16px;
  
}
</style>
</head>
<body onload="play()">

<?php
$servername = "localhost";
$database = "ponto";
$username = "pontopmc";
$password = "PontoCapivari2020";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// RECEBENDO OS DADOS PREENCHIDOS DO FORMULÁRIO !

session_start();

$matricula = $_SESSION["newsession"];

//$name = $_POST['id'];

	
//$template = "assAAAAqqQQWWWasas";

$newslleter = "INSERT INTO marcacao (matricula, date, hora) VALUES ('". $matricula ."', current_date(), current_time())";

if (mysqli_query($conn, $newslleter)) {
	echo "  <center><img src='relogio/img/pref.jpg'>

             
                    <div style='text-align: center; font-family: Arial;'>
                      
                     <h2 style='color: #AAA;'>Prefeitura Municipal de Capivari</h2>
                    </div>
  

	<center><div class='card'>
    <h2>Ponto Marcado!</h2>
    <div class='container'>
      <h4><b>Marcação Efetuada com Sucesso!</b></h4> 
    </div>
    </div>
    
    <audio id='audio'>
    <source src='audio/ok.mp3' type='audio/mp3' />
</audio>

<script type='text/javascript'>

    audio = document.getElementById('audio');

function play(){
    audio.play();
}


setInterval(function() {
    var div = document.querySelector('#counter');
    var count = div.textContent * 1 - 1;
    div.textContent = count;
    if (count <= 0) {
        window.location.replace('ponto.php');
    }
}, 1000);
</script>
<div hidden id='counter'>5</div>
  ";
} else {
      echo "Erro";
}

mysqli_close($conn);
?>

</body>
</html>