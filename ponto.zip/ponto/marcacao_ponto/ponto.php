<!DOCTYPE html>

<html>

    <head>

                <title>PONTO - PMC</title>

                <meta name="viewport" content="width=device-width, initial-scale=1">

                <link rel="stylesheet" href="css/bootstrap.css" />

                <link rel="stylesheet" href="css/fingertechweb.css" />

                <link rel="stylesheet" href="relogio/css/relogio.css" />

                

                <!--hora-->

                <script>

                    function startTime() {

                    var today = new Date();

                    var h = today.getHours();

                    var m = today.getMinutes();

                    var s = today.getSeconds();

                    m = checkTime(m);

                    s = checkTime(s);

                    document.getElementById('txt').innerHTML =

                    h + ":" + m + ":" + s;

                    var t = setTimeout(startTime, 500);

                    }

                    function checkTime(i) {

                    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10

                    return i;

                    }

             </script>

     </head>

    <body  onload="startTime()" >

    <br><br>

    <center><img src="relogio/img/pref.jpg">

    



    <div class="hora" id="txt"></div>

  

   <div class="p">

    <script> document.write(new Date().toLocaleDateString()); </script>

    </div>

                <?php



                session_start();

               

                $_SESSION["newsession"] = "";



                $_SESSION["newsession"];



                ?>



                <form  method="POST" action="pesquisa.php" class="form-group row justify-content-center" style="padding-top: 20px;">

                    <label for="matricula" class="col-1 col-form-label"><b>Matricula:</b></label><br>

                        <div class="col-6">

                         <input  class="form-control" type="text" placeholder="Matricula"  required name="matricula"> 

                        </div>

                         

                        <div class="col-1">

                            <button  class="btn btn-primary"  type="submit">ok!</button>

                        </div>

                </form><br><br>

                <h3 class="ti">DEPTO T.I. - 2020</h3></center>

     </body>

</html>