<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<meta charset="utf-8" />
		<title>CADASTRO PONTO - PMC</title>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/fingertechweb.css" />
	</head>
	
	<body>
		<main role="main" class="container">
			<div style="text-align: center;">
				<img src="relogio/img/pref.jpg"  />
				<h1>Serviço Ponto - PMC</h1>
				<h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>
			</div>
			
			<br />
            <form method="POST" action="export.php">
			<div style="padding-left: 380px;">
				<label for="data" ><b>Data:</b></label>
				<div class="col-6">
				  <input type="date" class="form-control"  placeholder="Data" name="data" required>
				</div>

				<label for="data1" ><b>Data:</b></label>
				<div class="col-6">
				  <input type="date" class="form-control"  placeholder="Data" name="data1" required>
				</div>
			
				
			<br><div style="padding-left: 130px;">
            <button  class="btn btn-primary"  type="submit">ok!</button>
				</div>
			</div>
			</form>
					
		</main>
		
		<footer class="footer py-3">
			<div style="text-align: center;">
				<span class="text-muted">
					<b>DEPTO T.I. - 2020</b> <br /> 
					
				</span>
			</div>
		</footer>
	</body>
	
	<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/fingertechweb.js"></script>
	
</html>

