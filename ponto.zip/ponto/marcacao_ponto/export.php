<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>EXPORTAR - PMC</title>
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 40%;
  text-align: center;
  background-color: lightgrey;
  font-family: Arial;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 2px 16px;
  
}
</style>
</head>
<body onload="play()">
<?php

//Criar o diretório de backup
$diretorio = 'backup/';


//Arquivo txt
$arquivo = $diretorio . "ponto_". $hoje . ".txt";

$data = $_POST['data'];
$data1 = $_POST['data1'];
$hoje = date("d_m_Y");

//Conectar na banco
$servername = "localhost";
$database = "ponto";
$username = "pontopmc";
$password = "PontoCapivari2020";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "
 <center><img src='relogio/img/pref.jpg'>

              <main role='main' class='container'>
                    <div style='text-align: center; font-family: Arial;'>
                      
                      
                      <h2 style='color: #AAA;'>Prefeitura Municipal de Capivari</h2>
                    </div>

<center><div class='card'>
<h2>TXT CRIADO COM SUCESSO!</h2>
<div class='container'>
   <a href='http://prefeituracapivari.sp.gov.br/ponto/marcacao_ponto/$arquivo' download='ponto.txt'><button> <b>DOWNLOAD! </button> </a>
</div>
</div>

<audio id='audio'>
<source src='audio/down.mp3' type='audio/mp3' />
</audio>

<script type='text/javascript'>

audio = document.getElementById('audio');

function play(){
audio.play();
}

</script>";




//abrir arquivo txt 
$arq = fopen($arquivo,"w+");

//faz consulta no banco de dados
$result = mysqli_query($conn, "select concat(repeat('0',10-char_length(matricula)),matricula) as mat, marcacao.date, marcacao.hora from marcacao
WHERE date BETWEEN '$data' AND '$data1'");

$cabecalho = "Matricula \t\t Data \t\t\t Hora\n\n";

fwrite($arq, $cabecalho);


while($escrever = mysqli_fetch_array($result)){
    $matricula = $escrever ['mat'];
    $date = $escrever ['date'];
    $hora = $escrever ['hora'];
    

    //escreve no arquivo txt

    fwrite($arq,  $matricula ."\t\t". $date . "\t\t". $hora . "\n");
}

//fecha o arquivo
fclose($arq);




?>


</body>
</html>