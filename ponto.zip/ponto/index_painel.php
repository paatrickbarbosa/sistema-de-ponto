<?php

session_start();

include('login/verifica_login.php');

?>

<!DOCTYPE html>

      

  <html>

      <head>

        <title>SERVIÇO PONTO - PMC</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	

        <link rel="stylesheet" href="css/navbar.css">

        <style>

          .btn-group .button {

            background-color: #007bff;

            border: 1px solid #007bff;

            color: white;

            padding: 15px 32px;

            text-align: center;

            text-decoration: none;

            display: inline-block;

            font-size: 16px;

            cursor: pointer;

            float: center;

          }



          .btn-group .button:not(:last-child) {

            border-right: none; /* Prevent double borders */

          }



          .btn-group .button:hover {

            background-color: DodgerBlue;

          }

        </style>

      </head>

      <body>

      <div class="topnav" id="myTopnav">

          <div class="navbar">

              <a class="active" href="http://localhost/digital%2023-09/ponto/"><i class="fa fa-fw fa-home"></i> Home</a> 

              <a href="login/cadastro.php"><i class="fa fa-fw fa-user-plus"></i> Cadastrar</a> 

              <a style="float: right;" href="login/logout.php"><i class="fa fa-fw fa-sign-out "></i> Sair</a>

        </div>

        </div>

           <br> <center><img src="marcacao_ponto/relogio/img/pref.jpg">



              <main role="main" class="container">

                    <div style="text-align: center; font-family: Arial;">

                      

                      <h1>Serviço Ponto - PMC</h1>

                      <h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>

                    </div>

                          

                    <div class="btn-group">    

                

                      <a target="_blank" href='cadastro_ponto/cadastro_usuario.php'> <button class="button"> <b>CADASTRO </button> </a>

                      <a target="_blank" href='marcacao_ponto/ponto.php'> <button class="button"> <b>PONTO </button> </a>

                      <a target="_blank" href='marcacao_ponto/p_matricula.php'> <button class="button"> <b>PESQUISA </button> </a>

                      <a target="_blank" href='excluir/index.php'> <button class="button"> <b>EXCLUIR</button> </a>

                      <a target="_blank" href='marcacao_ponto/pre_export.php'> <button class="button"> <b>EXPORTAR </button> </a>

                      <a target="_blank" href='gerar_pdf/index.php'> <button class="button"> <b>ESPELHO </button> </a>

                   </div>

                        

                   <footer >

                      <div style="text-align: center; font-family: Arial; padding-top: 150px;">

                          <span class="text-muted">

                            <b>DEPTO T.I. - 2020</b> <br /> 

                          </span>

                      </div>

                  </footer>

        </body>

</html>