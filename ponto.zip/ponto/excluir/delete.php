<!DOCTYPE html>

<html>

    <head>

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <title>EXCLUIR - PMC</title>

    <style>

.card {

  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);

  transition: 0.3s;

  width: 400px;

  height: 100px;

  text-align: center;

  background-color: lightgrey;

  font-family: Arial;

  border-radius: 15px;

}



.card:hover {

  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);

}



.container {

  padding: 2px 16px;

  

}

</style>

    </head>

    <body>			

        

                    <?php



                    $servername = "localhost";

                    $database = "ponto";

                    $username = "pontopmc";

                    $password = "PontoCapivari2020";



                    // Create connection

                    $conn = mysqli_connect($servername, $username, $password, $database);

                    // Check connection

                    if (!$conn) {

                        die("Connection failed: " . mysqli_connect_error());

                    }



                    //conexão



                    



                    $post = $_POST['matricula'];



                    $fe = "DELETE from client WHERE matricula = '$post'";





                    try {

                        $dbh = new PDO("mysql:host=$servername;dbname=$database", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );

                        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



                        if( !empty($_POST) ) {

                            $sth = $dbh->prepare($fe);

                           





                        } else {

                           echo "error";

                        }

                        $sth->execute();

                        echo "

                        <center><img src='img/pref.jpg'>



                        <main role='main' class='container'>

                              <div style='text-align: center; font-family: Arial;'>

                                

                                <h1>Serviço Ponto - PMC</h1>

                                <h2 style='color: #AAA;'>Prefeitura Municipal de Capivari</h2>

                              </div>

                                    

                        <center><div class='card'>

                        <h2>Usuário excluído com sucesso!</h2>

                        

                        </div>

                        ";

                    



                       

                        

                        



                        

                    } catch (PDOException $e) {

                        print "Error!: " . $e->getMessage() . "<br/>";

                        die();

                    }



                 

              

?>



<script>

setInterval(function() {

    var div = document.querySelector('#counter');

    var count = div.textContent * 1 - 1;

    div.textContent = count;

    if (count <= 0) {

        window.location.replace('../../ponto/index.php');

    }

}, 1000);

</script>

<div hidden id='counter'>5</div>

 

</script>



		</body>

</html>	