<!DOCTYPE html>
<html>
    <head>
                <title>EXCLUIR - PMC</title>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="stylesheet" href="css/bootstrap.css" />
                <link rel="stylesheet" href="css/fingertechweb.css" />
             
                
               
     </head>
    <body>
    
    <center><img src="img/pref.jpg">

              <main role="main" class="container">
                    <div style="text-align: center; font-family: Arial;">
                      
                      <h1>Serviço Ponto - PMC</h1>
                      <h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>
                    </div>


               

                <form  method="POST" action="delete.php" class="form-group row justify-content-center" style="padding-top: 20px;">
                    <label for="matricula" class="col-1 col-form-label"><b>Matricula:</b></label><br>
                        <div class="col-6">
                         <input  class="form-control" type="text" placeholder="Matricula"  required name="matricula"> 
                        </div>
                         
                        <div class="col-1">
                            <button  class="btn btn-primary"  type="submit">Excluir!</button>
                        </div>
                </form><br><br>
                <footer >
                      <div style="text-align: center; font-family: Arial; padding-top: 150px;">
                          <span class="text-muted">
                            <b>DEPTO T.I. - 2020</b> <br /> 
                          </span>
                      </div>
                  </footer>
     </body>
</html>