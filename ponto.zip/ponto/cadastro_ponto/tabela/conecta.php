<?php

session_start();

$localhost = "localhost";
$user = "pontopmc";
$pass = "PontoCapivari2020";
$banco = "ponto";



$conecta = mysqli_connect($localhost,$user,$pass,$banco);
mysqli_set_charset($conecta, "utf8");

?>