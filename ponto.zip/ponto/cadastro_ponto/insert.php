
<?php
    $servidor = "localhost";
    $usuario = "root";
    $senha = "";
    $dbname = "teste";
    
    //Criar a conexao
    $conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

    try {
       // $mysqli=new mysqli($servidor,$usuario,$senha,$bancodedados);
	    $dbh = new PDO("mysql:host=$servidor;dbname=$dbname", $usuario, $senha, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
	    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        
		



	    $stmt = $dbh->prepare("insert into client (matricula ) values (?);");
        
        $stmt->bindParam(1, $matricula);
        
        $matricula = strtoupper($_POST["matricula"]);
        if($stmt->execute())
        

        echo ""; //nao apagar - exibia ramo


        //INSERT INTO ramo_x_empresa (r_idramo, e_idempresa) VALUES ($idaramo,$ramo);
        
    } catch (PDOException $e) {
	    print "Error!: " . $e->getMessage() . "<br/>";
	    die();
	}
	
	
//$_SESSION['cnpj1'] = $cnpj;

?>
<div class="card">

  <h1></h1>
  <p class="title"><b>Cadastro Realizado!</b></p>
 
  <form action="index.php">
  <p><button >Voltar</button></p>
</form>
</div>

<!--<br><a href="index.php"></a>-->
</body>
</html>
