<?php
require_once("Controller.php");

$obj = new Controller();
$table = $obj->selectDB();
?>
<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<meta charset="utf-8" />
		<title>CADASTRO PONTO - PMC</title>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/fingertechweb.css" />
	</head>
	
	<body>
		<main role="main" class="container">
			<div style="text-align: center;">
				<img src="img/pref.jpg"  />
				<h1>Serviço Ponto - PMC</h1>
				<h2 style="color: #AAA;">Prefeitura Municipal de Capivari</h2>
			</div>
			
			<br />
			<div style="padding-left: 380px;">
				<label for="inputName" ><b>Nome:</b></label>
				<div class="col-6">
				  <input type="text" class="form-control" id="inputName" placeholder="Digite seu nome completo" required>
				</div>

				<label for="inputMatricula" ><b>Matrícula:</b></label>
				<div class="col-6">
				  <input type="text" class="form-control" id="inputMatricula" placeholder="Digite sua Matrícula" required>
				</div>
				<label for="inputMao" ><b>Escolha a mão:</b></label> 
				<div class="col-6">
				 			<select  class="form-control" id="inputMao" name="inputMao"required>
						
								<option  value="D">Mão Direita</option>
								<option value="E">Mão Esquerda</option>
							
							</select>
				</div>
				 
					
				
			<br><div style="padding-left: 130px;">
					<button   class="btn btn-primary" id="btn-capture">Cadastrar</button>
				</div>
			</div>
			
			
			<!--<div hidden class="row" style="padding-left: 150px; padding-right: 150px; margin-bottom: 20px;">
				<table class="table table-condensed">
					<thead class="thead-light">
						<tr hidden>
							<th scope="col" class="col-1">ID</th>
							<th scope="col" class="col-2">Nome</th>
							<th scope="col" class="col-8">Template</th>
							<th scope="col" class="col-1">Ação</th>
						</tr>
					</thead>
					<tbody>
						<?php echo $table; ?>
					</tbody>
				</table>
			</div>-->
			
		</main>
		
		<footer class="footer py-3">
			<div style="text-align: center;">
				<span class="text-muted">
					<b>DEPTO T.I. - 2020</b> <br /> 
					
				</span>
			</div>
		</footer>
	</body>
	
	<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/fingertechweb.js"></script>
	
</html>

